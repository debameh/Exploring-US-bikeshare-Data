The datasets used in this project are available on kaggle under U.S bikeshare data.

    problems encountered during the course of carrying out the project were resolved by searching for similar ones on StackOverflow

    Pandas library to help with datetime conversion